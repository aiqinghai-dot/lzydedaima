#pragma once
#include<Windows.h>
class Shape
{
private:
	int x1, y1, x2, y2;
public:
	Shape(int x1, int y1, int x2, int y2)
		:x1(x1), y1(y1), x2(x2), y2(y2) {};
	virtual void draw(HDC hdc) = 0;
	virtual void dowm() = 0;
	~Shape() {};
};

